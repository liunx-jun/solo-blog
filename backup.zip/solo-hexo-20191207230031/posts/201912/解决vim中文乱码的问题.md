title: 解决vim中文乱码的问题
date: '2019-12-05 21:38:38'
updated: '2019-12-05 21:41:09'
tags: [vim]
permalink: /articles/2019/12/05/1575553118208.html
---
![](https://img.hacpai.com/bing/20180515.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

### 概述
在使用vultr的debian主机的时候，发现用vim编辑shell脚本时中文乱码。这里记录下解决的方法。

### 解决方式
编辑vim配置文件
```shell
vim /etc/vim/vimrc
```
在后面追加配置如下
```text
set fileencodings=utf-8,gbk,utf-16le,cp1252,iso-8859-15,ucs-bom 
set termencoding=utf-8 
set encoding=utf-8
```

保存退出，这样所有的utf-8的文件打开一般就不会乱码了
